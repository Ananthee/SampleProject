package com.niit.daoangulardemo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.niit.daoangulardemo.dao.ProductDAO;
import com.niit.daoangulardemo.dao.ProductDAOImpl;
import com.niit.daoangulardemo.model.Product;

@Controller
public class HomeController {

	@Autowired
	ProductDAO productDAO;
	
	//ProductDAO productDAO=new ProductDAOImpl();
	
	@RequestMapping("/")
	public ModelAndView products()
	{
		List<Product> products=productDAO.getAllProducts();
		String productList=new Gson().toJson(products);
		ModelAndView model=new ModelAndView("index");
		model.addObject("productList", productList);
		
		return model;
		
	}
	
	@RequestMapping("/add")
	public String addProduct()
	{
		Product product=new Product();
		product.setProductName("Nikon D700");
		product.setPrice(105000);
		product.setCategory("Camera");
		productDAO.addProduct(product);
		
		
		
		return "redirect:/";
		
	}
	
	
	@RequestMapping("/delete")
	public String deleteProduct()
	{
		Product product=productDAO.getProductById(1);
		
		productDAO.deleteProduct(product);
		
		
		
		return "redirect:/";
		
	}
	@RequestMapping("/update")
	public String updateProduct()
	{
		Product product=productDAO.getProductById(0);
		product.setPrice(110000);
		productDAO.updateProduct(product);
		
		
		
		return "redirect:/";
		
	}
	
	
	
	
	
	
	
	
	
	
}
