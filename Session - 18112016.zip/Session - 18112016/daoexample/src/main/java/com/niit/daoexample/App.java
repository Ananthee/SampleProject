package com.niit.daoexample;

import com.niit.daoexample.dao.ProductDAO;
import com.niit.daoexample.dao.ProductDAOImpl;
import com.niit.daoexample.model.Product;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	ProductDAO productDAO = new ProductDAOImpl();

        //print all products
        for (Product product : productDAO.getAllProducts()) {
           System.out.println("Product: [ID : " + product.getProductId() + ", Name : " + product.getProductName() + " ]");
        }


        //update product
        Product product=productDAO.getAllProducts().get(0);
        product.setProductName("60D");
        productDAO.updateProduct(product);

        //get the product
        productDAO.getProduct(0);
        System.out.println("Product: [RollNo : " + product.getProductId() + ", Name : " + product.getProductName() + " ]");	
    }
}
