package com.niit.webfow.example.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {
	
	@RequestMapping("/")
	public String indexPage()
	{
		return "index";
	}

	@RequestMapping(value="/Page1")
	public String page1()
	{
		return "Page1";
	}
	@RequestMapping(value="/Page2")
	public String page2()
	{
		return "Page2";
	}
}
