package com.niit.daoangulardemo.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.niit.daoangulardemo.dao.ProductDAO;
import com.niit.daoangulardemo.dao.ProductDAOImpl;
import com.niit.daoangulardemo.model.Product;

@Controller
public class HomeController {

	ProductDAO productDAO=new ProductDAOImpl();
	
	@RequestMapping("/")
	public ModelAndView products()
	{
		List<Product> products=productDAO.getAllProducts();
		String productList=new Gson().toJson(products);
		ModelAndView model=new ModelAndView("index");
		model.addObject("productList", productList);
		
		return model;
		
	}
	
}
