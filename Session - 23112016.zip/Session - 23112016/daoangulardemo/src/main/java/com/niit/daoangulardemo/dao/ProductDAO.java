package com.niit.daoangulardemo.dao;

import java.util.List;

import com.niit.daoangulardemo.model.Product;

public interface ProductDAO {
	
	public List<Product> getAllProducts();
	public Product getProductById();
	public void addProduct(Product product);
	public void updateProduct(Product product);
	public void deleteProduct(Product product);

}
